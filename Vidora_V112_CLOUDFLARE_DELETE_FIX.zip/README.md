Vidora V112 - Cloudflare Pages Delete backend.

Required Cloudflare secrets: CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET, VIDORA_OWNER_UID.
