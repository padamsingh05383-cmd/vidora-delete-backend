function json(status, payload) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store"
    }
  });
}

function sign(params, secret) {
  const text = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== "")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return text;
}

async function sha1Hex(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-1", bytes);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

async function destroyCloudinary(env, { publicId, resourceType }) {
  if (!publicId) return { ok: true, skipped: true };

  const timestamp = Math.floor(Date.now() / 1000);
  const params = { public_id: publicId, timestamp, invalidate: "true" };
  const signature = await sha1Hex(sign(params, env.CLOUDINARY_API_SECRET));

  const body = new URLSearchParams({
    ...params,
    api_key: env.CLOUDINARY_API_KEY,
    signature
  });

  const endpoint = `https://api.cloudinary.com/v1_1/${encodeURIComponent(env.CLOUDINARY_CLOUD_NAME)}/${resourceType}/destroy`;
  const resp = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });

  const data = await resp.json().catch(() => ({}));
  const result = String(data.result || "").toLowerCase();
  if (!resp.ok || (data.result && !["ok", "not found"].includes(result))) {
    throw new Error(data.error?.message || data.result || `Cloudinary ${resourceType} delete failed (${resp.status})`);
  }
  return data;
}

export async function onRequestPost(context) {
  const { request, env } = context;

  const required = [
    "CLOUDINARY_CLOUD_NAME",
    "CLOUDINARY_API_KEY",
    "CLOUDINARY_API_SECRET",
    "VIDORA_OWNER_UID"
  ];
  const missing = required.filter(k => !env[k]);
  if (missing.length) return json(500, { ok: false, error: "Cloudflare environment variables missing: " + missing.join(", ") });

  let body = {};
  try {
    body = await request.json();
  } catch (_) {
    return json(400, { ok: false, error: "Invalid JSON" });
  }

  if (String(body.ownerUid || "").trim() !== String(env.VIDORA_OWNER_UID).trim()) {
    return json(403, { ok: false, error: "Owner check failed" });
  }

  const publicId = String(body.publicId || "").trim();
  if (!publicId) return json(400, { ok: false, error: "publicId is required" });

  try {
    const video = await destroyCloudinary(env, {
      publicId,
      resourceType: "video"
    });

    let image = { ok: true, skipped: true };
    const thumb = String(body.thumbnailUrl || "").trim();
    if (thumb.includes("res.cloudinary.com/") && thumb.includes("/image/upload/")) {
      const marker = "/image/upload/";
      let p = (thumb.split(marker)[1] || "").split("?")[0].replace(/^v\d+\//, "");
      p = p.replace(/\.[A-Za-z0-9]+$/, "");
      const parts = p.split("/");
      while (parts.length && /^(?:c_|w_|h_|ar_|q_|f_|g_|e_|so_|eo_|vc_|du_|fl_|dpr_|x_|y_|z_)/.test(parts[0])) parts.shift();
      const imagePublicId = parts.join("/");
      if (imagePublicId) {
        try {
          image = await destroyCloudinary(env, {
            publicId: imagePublicId,
            resourceType: "image"
          });
        } catch (e) {
          image = { ok: false, error: e.message || "thumbnail delete failed" };
        }
      }
    }

    return json(200, { ok: true, video, image });
  } catch (e) {
    return json(500, { ok: false, error: e.message || "Cloudinary delete failed" });
  }
}
